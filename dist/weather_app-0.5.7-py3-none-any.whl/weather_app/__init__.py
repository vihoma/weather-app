"""Weather Application package."""
