"""CLI command implementations for weather application.

This module contains subcommands for weather, setup, cache, and configuration.
"""

__all__ = []
