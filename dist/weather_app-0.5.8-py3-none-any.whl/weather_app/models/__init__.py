"""Models package for weather data structures."""

# Models package initialization
from .weather_data import WeatherData

__all__ = ["WeatherData"]
