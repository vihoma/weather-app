"""CLI module for weather application.

This package contains command-line interface components built with Click.
"""

__version__ = "0.1.0"
